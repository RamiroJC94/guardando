const express = require("express");
const app = express();
const handlebars = require("express-handlebars");
const motor = handlebars.create({
	defaultLayout:"layout",
	extname:".hbs"}
);
app.engine(".hbs",motor.engine);
app.set("view engine",".hbs");

app.get("/listapalabra", (req,res) => {
	res.render("listapalabra");
});

app.get("/altapalabra", (req,res) => {
	res.render("formularioalta");
});

app.get("/borrarpalabra", (req,res) => {
	res.render("borrarpalabra");
});

app.listen(3000,() => {
	console.log("servidor inicializado");
})