const express = require("express");
const app = express();
const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/pruebamongoose");

var schemaPersona = new mongoose.Schema({
	nombre: String,
	apellido: String,
	edad: Number
});

var Persona = mongoose.model("Persona", schemaPersona);

app.get("/",(req,res) => {
	var juan = new Persona({
		nombre: "Juan", 
		apellido: "Diaz",
		edad: 40
	});

	juan.save((err) => {
		if(err){
			res.send("No se pudo guardar " +err);		
		}
		else
		{
			res.send("Juan se guardo correctamente");
		}
	})	
});

app.get("/buscar",(req,res) => {
	Persona.find({apellido: "Diaz"}).exec((err,personas) => {
		res.json(personas);
	});
});

var db = mongoose.connection;
db.on("error",console.error.bind(console,'connection error'));
db.once("open", () => {
	console.log("Se conecto a la base de datos");
	app.listen(3000,() => {
		console.log("Server inicializado");
	})
});
