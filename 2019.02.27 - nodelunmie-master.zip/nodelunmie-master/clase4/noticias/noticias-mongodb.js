const mongoDriver = require("mongodb");
const mongoClient = mongoDriver.MongoClient;
const ObjectId = mongoDriver.ObjectId;

const url = "mongodb://localhost:27017";
const dbname = "noticias";
var dbNoticias;
var collectionNoticias;

mongoClient.connect(url,(err,client) => {
	dbNoticias = client.db(dbname);
	collectionNoticias = dbNoticias.collection("noticias");
});


var _insert = (json,callback) => {
	collectionNoticias.insert(json, (err,res) => {
		if(err){
			callback(err);
		}else{
			if(res.result.n>=1){
				callback(null);
			}else{
				callback("No se inserto el registro");
			}			
		}
	})
};

const _find = (callback) => {
	collectionNoticias.find().toArray((err,array) => {
		callback(err,array);
	});
};

const _findOne = (id, callback) => {
	collectionNoticias.find({ _id: ObjectId(id) }).toArray((err,array) => {
		callback(err,array);
	});
};

module.exports = {
	/** Inserta una noticia en la base de datos de MongoDB */
	Insert: _insert,
	/** Busca noticias en la base de datos */
	Find: _find,
	/** Dado un id, busca una noticia en la base de datos */
	FindOne: _findOne
}