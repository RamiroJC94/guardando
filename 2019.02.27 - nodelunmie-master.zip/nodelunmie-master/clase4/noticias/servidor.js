const express = require("express");
const handlebars = require("express-handlebars");
const hb = require("handlebars");
const bodyParser = require("body-parser");
const noticiasMongoDB = require("./noticias-mongodb");

const app = express();
const motor = handlebars.create({
	defaultLayout:"layout",
	extname:".hbs"}
);

app.engine(".hbs",motor.engine);
app.set("view engine",".hbs");

app.use(express.static("estatico"));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

var dibujarTitulo = (texto) => new hb.SafeString("<h3>"+texto+"</h3>");

app.get("/",(req,res) => {
	noticiasMongoDB.Find((err,datos) => {
		res.render("listado",{
			noticias: datos
		});
	});
	
});

app.get("/noticia",(req,res) => {
	var id = req.query.q;

	noticiasMongoDB.FindOne(id,(err,arr) => {
		res.render("noticia",{
			noticia: arr[0],
			helpers: {
				generarTitulo: dibujarTitulo
			},
			layout: "layoutnoticias"
		});
	})

	
});

app.get("/adminnoticias",(req,res) => {
	res.render("nuevanoticia");
});

app.post("/adminnoticias",(req,res) => {
	const nuevanoticia = {
		titulo: req.body.titulo,
		resumen: req.body.resumen,
		cuerpo: req.body.cuerpo,
		autor: req.body.autor,
		fecha: req.body.fecha
	};
	noticiasMongoDB.Insert(nuevanoticia,(err) => {
		if(err){
			res.send("Error al insertar el registro");
		}else{
			res.render("postnuevanoticia",nuevanoticia);
		}
	});	
});

app.listen(3000, () => {
	console.log("Escuchando en el puerto 3000");
});