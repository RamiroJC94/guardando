function a(){
	var x = 1;
	if(true){
		var x = 2;
		console.log(x);
	}
	console.log(x);
}

function b(){
	let x = 1;
	if(true){
		let x = 2;
		console.log(x);
	}
	console.log(x);
}

a();
b();