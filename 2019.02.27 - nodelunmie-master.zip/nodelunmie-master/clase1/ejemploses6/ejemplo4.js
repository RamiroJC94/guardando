const constante = 1;	
//Genera error porque es constante
//constante = 2; 
console.log(constante);

if(true){
	let constante2 = 100;
}

console.log(constante2);