
function a(){
	console.log(b);
	console.log(c);

	var b = 1;
	let c = 2;
}

a();
