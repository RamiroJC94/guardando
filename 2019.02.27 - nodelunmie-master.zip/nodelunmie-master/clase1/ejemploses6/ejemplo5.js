function a(a1,a2){
	return a1 + a2;
}

var result = a(1,2);
console.log(result);

var b = function(){
	console.log("Funcion B");
}

b();

() => { /* Cuerpo de la funcion */ }

var cuadrado = a => a * a;
console.log(cuadrado(2));
var sinparametros = () => console.log("0 params");
sinparametros();
var completa = (a,b) => { let c = a + b; console.log(c); };
completa(10,20);

var edad = 30;

var tipo = edad > 21 ? "es mayor" : "es menor";

console.log(tipo);