const http = require("http");
const home = require("./home");
const js = require("./javascript");

var servidor = http.createServer((req,res) => {
	console.log("request "+req.url);
	switch(req.url){
		case "/":
			res.writeHead(200,{"content-type":"text/html"});
			res.end(home);
			break;
		case "/app.js":
			res.writeHead(200,{"content-type":"text/javascript"});
			res.end(js);
			break;
		default:
			res.writeHead(200,{"content-type":"text/javascript"});
			res.end("PETICION ERRONEA "+req.url);
			break;


	}
});

servidor.listen(8080);
