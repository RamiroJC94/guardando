console.log("Hola Mundo!!!");

var fecha = new Date();

console.log(fecha);

//Error porque document no existe
//document.getElementById("id");