const http = require("http");

var servidor = http.createServer((req,res) => {
	res.writeHead(200,{"content-type":"text/html"});
	if(req.url == "/"){
		res.end("Hola <b>Mundo</b>!!!<br>");
	}
	else
	{
		var splitUsuario = req.url.toUpperCase().split("/USUARIO");
		
		if(splitUsuario.length>1){
			//Vino con la url /usuario
			if(splitUsuario[1]==""){
				res.end("Hola Usuario");
			}else{
				res.end("Hola "+splitUsuario[1]);
			}
		}else{
			res.end("Peticion erronea");
		}

	}

	
});

servidor.listen(8000);