document.getElementById('saludo').value = 'Hola Mundo';
document.getElementById('saludo').value = 'Chau Mundo';