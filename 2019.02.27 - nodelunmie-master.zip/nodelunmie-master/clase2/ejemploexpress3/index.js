const express = require("express");
const app = express();
const fs = require("fs");


app.get("/",(req,res)=> {
	fs.readFile("usuarios.html","utf-8",(err,datos) => {
			if(err){
				res.send("Hubo un error al leer el archivo");
			}else{
				console.log("Ya lei el archivo");
				res.send(datos);
			}
	});
	console.log("despues del readFile");
});

app.get("/app.js", (req,res) => {
	fs.readFile("pepito.js","utf-8",(err,datos) => {
			if(err){
				res.send("Error");
			}else{
				res.type("text/javascript");
				res.send(datos);
			}
	});
});

app.listen(3000,() => {
	console.log("Iniciado en puerto 3000");
})