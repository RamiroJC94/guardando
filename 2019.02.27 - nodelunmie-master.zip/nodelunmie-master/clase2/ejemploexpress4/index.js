const express = require("express");
const app = express();
const fs = require("fs");

app.use("/js",express.static("estatico_js"));
app.use("/img",express.static("imagenes"));

app.listen(4000,() => {
	console.log("Iniciado en puerto 4000");
})