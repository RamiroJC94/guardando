const express = require("express");
const app = express();

app.get("/",(req,res) => {
	res.send("Hola Mundo");
});

/*
app.get("/usuario", (req,res) => {
	res.send("<form method='post'><input type='submit'></form>");
});

app.post("/usuario",(req,res) => {
	res.send("POST a usuario");
});
*/

app.route("/usuario")
	.get((req,res) => {
		res.send("<form method='post'><input type='submit'></form>");
	})
	.post((req,res) => {
		res.send("POST a usuario");
	});

app.listen(3000,() => {
	console.log("Escuchando en el puerto 3000");
});