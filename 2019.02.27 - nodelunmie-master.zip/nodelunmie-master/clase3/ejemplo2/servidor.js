const express = require("express");
const handlebars = require("express-handlebars");
const hb = require("handlebars");

const app = express();
const motor = handlebars.create({
	defaultLayout:"layout",
	extname:".hbs"}
);

app.engine(".hbs",motor.engine);
app.set("view engine",".hbs");

app.use(express.static("estatico"));

var dibujarTitulo = (texto) => new hb.SafeString("<h3>"+texto+"</h3>");

const noticias = [
	{
		id: 1,
		titulo: "noticia 1",
		noticia: "cuerpo noticia 1",
		imagen: "https://dummyimage.com/300x200/000/fff"
	},
	{
		id: 2,
		titulo: "noticia2",
		noticia: "cuerpo noticia 2",
		imagen: "https://dummyimage.com/300x200/000/fff"
	},
	{
		id: 3,
		titulo: "noticia3",
		noticia: "cuerpo noticia 3",
		imagen: "https://dummyimage.com/300x200/000/fff"
	},
	{
		id: 4,
		titulo: "noticia4",
		noticia: "cuerpo noticia 4",
		imagen: "https://dummyimage.com/300x200/000/fff"
	},
];

app.get("/",(req,res) => {
	res.render("listado",{
		noticias: noticias
	});
});

app.get("/noticia",(req,res) => {
	var id = req.query.q;
	var not = noticias[id-1];
	res.render("noticia",{
		noticia: not,
		helpers: {
			generarTitulo: dibujarTitulo
		},
		layout: "layoutnoticias"
	});
});

app.listen(3000, () => {
	console.log("Escuchando en el puerto 3000");
});