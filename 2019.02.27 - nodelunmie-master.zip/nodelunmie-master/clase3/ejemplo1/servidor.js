const express = require("express");
const handlebars = require("express-handlebars");

//Tengo que tener la siguiente estructura
//de carpetas
// root
//    ->layouts
//    ->views

const app = express();
const motor = handlebars.create({
	defaultLayout:"layout",
	extname:".hbs"}
);

app.engine(".hbs",motor.engine);
app.set("view engine",".hbs");

app.get("/",(req,res) => {
	res.render("home");
});

app.get("/usuarios",(req,res) => {
	res.render("usuarios",{
		usuario: "Pepe",
		helpers: {
			foo: () => "Hola Pepe"
		}
	});
})

app.listen(3000, () => {
	console.log("Escuchando en el puerto 3000");
});