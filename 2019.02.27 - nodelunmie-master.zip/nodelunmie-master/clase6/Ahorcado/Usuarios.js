const mongoose = require("mongoose");
const schemas = require("./Schemas");
mongoose.connect("mongodb://localhost:27017/ahorcado");
const Usuario = mongoose.model("Usuario",schemas.UsuarioSchema);

const _ObtenerOCrear = function(Email,callback){
    Usuario.findOne({Email: Email}, (err,user) => {
        if(user==null){
            _Crear(Email,(err,nuevousuario) => {
                callback(err,nuevousuario);
            });
        }else{
            callback(err,user);
        }
    });
}

const _Crear = function(Email,callback){
    var nuevoUsuario = new Usuario({
        _id: new mongoose.Types.ObjectId(),
        Email: Email
    });
    nuevoUsuario.save(callback);
}

const _ObtenerPorId = function(id,callback){
    Usuario.findOne({_id: new mongoose.Types.ObjectId(id)},callback);
}

const _ActualizarPalabra = function(id,palabra,palabraadivinada,callback){
    _ObtenerPorId(id,(err,user) => {
        if(err || user==null){
            callback(err,user);
        }else{
            user.Palabra = palabra;
            user.PalabraAdivinada = palabraadivinada;
            user.LetrasElegidas=[];
            user.save(callback);
        }
    });
}

const _ActualizarPalabraAdivinada = function(id,palabraadivinada,letraelegida,callback){
    _ObtenerPorId(id,(err,user) => {
        if(err){
            callback(err);
        }else{
            user.PalabraAdivinada = palabraadivinada;
            user.LetrasElegidas.push(letraelegida);
            user.save(callback);
        }
    });
}

module.exports = {
    ObtenerOCrear: _ObtenerOCrear,
    ObtenerPorId: _ObtenerPorId,
    ActualizarPalabra: _ActualizarPalabra,
    ActualizarPalabraAdivinada: _ActualizarPalabraAdivinada
}