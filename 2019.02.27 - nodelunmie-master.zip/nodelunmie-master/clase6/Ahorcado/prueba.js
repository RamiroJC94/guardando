const Palabras = require("./Palabras");

Palabras.ObtenerAlAzar((err,palabra) => {
    if(!err){
        console.log(palabra);
        console.log(palabra.Palabra.replace(/./g,'-'));
    }
})