const mongoose = require("mongoose");
const schemas = require("./Schemas");
mongoose.connect("mongodb://localhost:27017/ahorcado");
const Palabra = mongoose.model("Palabra",schemas.PalabraSchema);

const _AgregarPalabra = function(nuevapalabra,callback) {
    Palabra.findOne({Palabra: nuevapalabra.toUpperCase()}, (err,palabra) => {
        if(palabra==null){
            _Crear(nuevapalabra,callback);
        }else{
            callback(err,palabra);
        }
    });
}

const _Crear = function(nuevapalabra,callback){
    var objeto = new Palabra({
        _id: new mongoose.Types.ObjectId(),
        Palabra: nuevapalabra.toUpperCase()
    });
    objeto.save(callback);
}

const _ObtenerAlAzar = function(callback){
    Palabra.find((err,palabras) => {
        if(palabras){
            var palabra = palabras[Math.floor(Math.random()*palabras.length)];
            callback(null,palabra)
        }else{
            callback(err);
        }
    });
}

module.exports = {
    AgregarPalabra: _AgregarPalabra,
    ObtenerAlAzar: _ObtenerAlAzar
}