const Mongoose = require("mongoose");
const Schema = Mongoose.Schema;

const _UsuarioSchema = new Schema({
    _id: Schema.Types.ObjectId,
    Email: String,
    Palabra: String,
    PalabraAdivinada: String,
    LetrasElegidas: [String]
});

const _PalabraSchema = new Schema({
    _id: Schema.Types.ObjectId,
    Palabra: String
});

module.exports = {
    PalabraSchema: _PalabraSchema,
    UsuarioSchema: _UsuarioSchema
}